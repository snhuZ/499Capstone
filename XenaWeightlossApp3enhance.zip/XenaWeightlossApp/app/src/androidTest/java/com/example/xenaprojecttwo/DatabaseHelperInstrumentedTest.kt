package com.example.xenaprojecttwo

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DatabaseHelperInstrumentedTest {
    private lateinit var context: Context
    private lateinit var db: DatabaseHelper

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase("weight_tracker.db")
        db = DatabaseHelper(context)
    }

    @After
    fun cleanup() {
        db.close()
        context.deleteDatabase("weight_tracker.db")
    }

    @Test
    fun relatedHealthDataSupportsCrudAndFiltering() {
        val userId = db.createUser("database_test", "ValidPassword1!")
        assertNotEquals(-1, userId)
        assertTrue(db.updateProfile(userId, "Test User", "test@example.com", 65.0, 150.0, 1800))

        val firstId = db.addHealthRecord(userId, "2026-07-01", 180.0, 2100)
        val secondId = db.addHealthRecord(userId, "2026-07-08", 178.0, 1950)
        assertNotEquals(-1L, firstId)
        assertNotEquals(-1L, secondId)
        assertEquals(-1L, db.addHealthRecord(userId, "2026-07-08", 177.0, 1900))

        val filtered = db.searchHealthRecords(userId, "2026-07-05", "2026-07-31")
        assertEquals(1, filtered.size)
        assertEquals(1950, filtered.first().calories)
        assertTrue(filtered.first().bmi != null)

        assertTrue(db.updateHealthRecord(secondId, userId, "2026-07-09", 177.5, 1850))
        assertEquals("2026-07-09", db.searchHealthRecords(userId, null, null).first().date)

        assertTrue(db.deleteHealthRecord(firstId, userId))
        assertFalse(db.searchHealthRecords(userId, null, null).any { it.id == firstId })
    }
}
