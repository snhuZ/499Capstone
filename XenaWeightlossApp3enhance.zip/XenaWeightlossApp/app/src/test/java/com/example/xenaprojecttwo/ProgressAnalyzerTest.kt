package com.example.xenaprojecttwo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

// Unit tests for algorithms.
class ProgressAnalyzerTest {
    private val analyzer = ProgressAnalyzer()

    @Test
    fun calculatesBmiWeeklyAverageProgressTrendAndPrediction() {
        val entries = listOf(
            WeightEntry("2026-07-01", 200.0),
            WeightEntry("2026-07-08", 198.0),
            WeightEntry("2026-07-15", 196.0)
        )

        val report = analyzer.analyze(entries, 65.0, 180.0, "2026-07-15")

        assertEquals(32.6, report.bmi!!, 0.1)
        assertEquals(196.0, report.sevenDayAverage!!, 0.01)
        assertEquals(20.0, report.progressPercent!!, 0.01)
        assertEquals(ProgressAnalyzer.Trend.LOSING, report.trend)
        assertEquals(-2.0, report.weeklyRate!!, 0.01)
        assertEquals("2026-09-09", report.estimatedGoalDate)
        assertTrue(report.reminder.contains("up to date"))
    }

    @Test
    fun sortsUnorderedRecordsAndIgnoresInvalidDates() {
        val entries = listOf(
            WeightEntry("not-a-date", 400.0),
            WeightEntry("2026-07-03", 190.0),
            WeightEntry("2026-07-01", 192.0)
        )

        val report = analyzer.analyze(entries, 70.0, 180.0, "2026-07-04")

        assertEquals(190.0, report.currentWeight!!, 0.01)
        assertEquals(2, report.validEntryCount)
        assertEquals(ProgressAnalyzer.Trend.LOSING, report.trend)
    }

    @Test
    fun avoidsPredictionWhenTrendMovesAwayFromGoal() {
        val entries = listOf(
            WeightEntry("2026-07-01", 190.0),
            WeightEntry("2026-07-08", 192.0)
        )

        val report = analyzer.analyze(entries, 65.0, 175.0, "2026-07-08")

        assertEquals(0.0, report.progressPercent!!, 0.01)
        assertEquals(ProgressAnalyzer.Trend.GAINING, report.trend)
        assertNull(report.estimatedGoalDate)
    }

    @Test
    fun reportsMissingProfileAndInsufficientHistorySafely() {
        val report = analyzer.analyze(
            listOf(WeightEntry("2026-07-20", 160.0)),
            null,
            null,
            "2026-07-23"
        )

        assertNull(report.bmi)
        assertNull(report.progressPercent)
        assertEquals(ProgressAnalyzer.Trend.INSUFFICIENT_DATA, report.trend)
        assertTrue(report.reminder.contains("3 days"))
    }
}
