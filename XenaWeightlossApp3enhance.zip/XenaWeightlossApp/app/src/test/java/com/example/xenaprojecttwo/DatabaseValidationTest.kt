package com.example.xenaprojecttwo

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DatabaseValidationTest {
    @Test
    fun dateValidationRejectsImpossibleDates() {
        assertTrue(DatabaseValidation.validDate("2026-07-31"))
        assertFalse(DatabaseValidation.validDate("2026-02-30"))
        assertFalse(DatabaseValidation.validDate("07/31/2026"))
    }

    @Test
    fun healthRecordValidationEnforcesDatabaseRanges() {
        assertTrue(DatabaseValidation.validHealthRecord("2026-07-31", 175.5, 1900))
        assertFalse(DatabaseValidation.validHealthRecord("2026-07-31", 20.0, 1900))
        assertFalse(DatabaseValidation.validHealthRecord("2026-07-31", 175.5, 20000))
    }

    @Test
    fun profileValidationEnforcesHealthRanges() {
        assertTrue(DatabaseValidation.validProfile(65.0, 150.0, 1800))
        assertFalse(DatabaseValidation.validProfile(20.0, 150.0, 1800))
        assertFalse(DatabaseValidation.validProfile(65.0, 150.0, 7000))
    }

    @Test
    fun dateRangeRequiresChronologicalOrder() {
        assertTrue(DatabaseValidation.validDateRange("2026-01-01", "2026-12-31"))
        assertTrue(DatabaseValidation.validDateRange(null, "2026-12-31"))
        assertFalse(DatabaseValidation.validDateRange("2026-12-31", "2026-01-01"))
    }
}
