package com.example.xenaprojecttwo

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

//Third Enchancement: validated CRUD
class WeightListActivity : AppCompatActivity() {
    private val smsPermissionRequest = 100

    private lateinit var dateInput: EditText
    private lateinit var weightInput: EditText
    private lateinit var calorieInput: EditText
    private lateinit var fromDateInput: EditText
    private lateinit var toDateInput: EditText
    private lateinit var saveButton: Button
    private lateinit var recordList: ListView
    private lateinit var db: DatabaseHelper
    private lateinit var adapter: ArrayAdapter<String>

    private val displayRows = ArrayList<String>()
    private var displayedRecords: List<HealthRecord> = emptyList()
    private var userId = -1
    private var editingRecordId: Long? = null
    private val phoneNumber = "5551234567"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_list)

        userId = intent.getIntExtra("USER_ID", -1)
        if (userId < 0) { finish(); return }
        db = DatabaseHelper(this)

        dateInput = findViewById(R.id.etDate)
        weightInput = findViewById(R.id.etWeight)
        calorieInput = findViewById(R.id.etCalories)
        fromDateInput = findViewById(R.id.etFromDate)
        toDateInput = findViewById(R.id.etToDate)
        saveButton = findViewById(R.id.btnAdd)
        recordList = findViewById(R.id.listHealthRecords)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayRows)
        recordList.adapter = adapter

        saveButton.setOnClickListener { saveRecord() }
        findViewById<Button>(R.id.btnFilter).setOnClickListener { applyFilter() }
        findViewById<Button>(R.id.btnClearFilter).setOnClickListener {
            fromDateInput.text.clear()
            toDateInput.text.clear()
            loadRecords()
        }
        findViewById<Button>(R.id.btnProgress).setOnClickListener {
            startActivity(Intent(this, ProgressActivity::class.java).putExtra("USER_ID", userId))
        }
        findViewById<Button>(R.id.btnProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java).putExtra("USER_ID", userId))
        }

        recordList.setOnItemLongClickListener { _, _, position, _ ->
            showRecordActions(displayedRecords[position])
            true
        }
        loadRecords()
    }

    override fun onResume() {
        super.onResume()
        if (::db.isInitialized) loadRecords(currentFromDate(), currentToDate())
    }

    private fun saveRecord() {
        val date = dateInput.text.toString().trim()
        val weight = weightInput.text.toString().toDoubleOrNull()
        val calories = calorieInput.text.toString().trim().let {
            if (it.isEmpty()) null else it.toIntOrNull()
        }

        if (!DatabaseValidation.validDate(date)) {
            dateInput.error = "Enter a real date as yyyy-MM-dd"
            return
        }
        if (weight == null || weight !in 50.0..1000.0) {
            weightInput.error = "Enter a weight from 50 to 1000 lb"
            return
        }
        if (calorieInput.text.isNotBlank() && (calories == null || calories !in 0..15000)) {
            calorieInput.error = "Enter 0–15000 calories"
            return
        }

        val editingId = editingRecordId
        val success = if (editingId == null) {
            db.addHealthRecord(userId, date, weight, calories) != -1L
        } else {
            db.updateHealthRecord(editingId, userId, date, weight, calories)
        }

        if (!success) {
            Toast.makeText(this, "That date already exists or the record is invalid", Toast.LENGTH_LONG).show()
            return
        }

        Toast.makeText(this, if (editingId == null) "Health record added" else "Health record updated", Toast.LENGTH_SHORT).show()
        clearEditor()
        loadRecords(currentFromDate(), currentToDate())

        val goal = db.getProfile(userId)?.goalWeight
        if (goal != null && weight <= goal) handleGoalReached(weight)
    }

    private fun showRecordActions(record: HealthRecord) {
        AlertDialog.Builder(this)
            .setTitle(record.date)
            .setItems(arrayOf("Edit record", "Delete record")) { _, choice ->
                if (choice == 0) beginEditing(record) else confirmDelete(record)
            }
            .show()
    }

    private fun beginEditing(record: HealthRecord) {
        editingRecordId = record.id
        dateInput.setText(record.date)
        weightInput.setText(record.weight.toString())
        calorieInput.setText(record.calories?.toString().orEmpty())
        saveButton.text = "Update record"
        dateInput.requestFocus()
    }

    private fun confirmDelete(record: HealthRecord) {
        AlertDialog.Builder(this)
            .setTitle("Delete this record?")
            .setMessage("${record.date} • ${record.weight} lb\nRelated BMI and calorie data will also be removed.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                if (db.deleteHealthRecord(record.id, userId)) {
                    if (editingRecordId == record.id) clearEditor()
                    loadRecords(currentFromDate(), currentToDate())
                    Toast.makeText(this, "Record deleted", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun clearEditor() {
        editingRecordId = null
        dateInput.text.clear()
        weightInput.text.clear()
        calorieInput.text.clear()
        saveButton.text = "Add health record"
    }

    private fun applyFilter() {
        val from = currentFromDate()
        val to = currentToDate()
        if (!DatabaseValidation.validDateRange(from, to)) {
            Toast.makeText(this, "Enter a valid date range using yyyy-MM-dd", Toast.LENGTH_LONG).show()
            return
        }
        loadRecords(from, to)
    }

    private fun currentFromDate() = fromDateInput.text.toString().trim().ifEmpty { null }
    private fun currentToDate() = toDateInput.text.toString().trim().ifEmpty { null }

    private fun loadRecords(fromDate: String? = null, toDate: String? = null) {
        displayedRecords = db.searchHealthRecords(userId, fromDate, toDate)
        displayRows.clear()
        displayRows.addAll(displayedRecords.map { record ->
            val bmi = record.bmi?.let { "BMI %.1f".format(it) } ?: "BMI —"
            val calories = record.calories?.let { "$it cal" } ?: "Calories —"
            "${record.date}   •   %.1f lb\n$bmi   •   $calories".format(record.weight)
        })
        adapter.notifyDataSetChanged()
        findViewById<android.widget.TextView>(R.id.tvRecordCount).text =
            "${displayedRecords.size} saved ${if (displayedRecords.size == 1) "record" else "records"}"
    }

    private fun handleGoalReached(weight: Double) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendGoalSms(weight)
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), smsPermissionRequest)
        }
    }

    private fun sendGoalSms(weight: Double) {
        try {
            applicationContext.getSystemService(SmsManager::class.java)
                .sendTextMessage(phoneNumber, null, "Congrats! You reached your goal weight: $weight", null, null)
            Toast.makeText(this, "Goal SMS sent", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == smsPermissionRequest) {
            val message = if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                "SMS permission granted. Goal alerts can be sent."
            } else {
                "SMS permission denied. The app will still work without text alerts."
            }
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }
}
