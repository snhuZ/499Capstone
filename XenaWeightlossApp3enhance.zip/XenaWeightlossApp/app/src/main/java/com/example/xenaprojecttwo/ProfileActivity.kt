package com.example.xenaprojecttwo

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private var userId = -1
    private lateinit var name: EditText
    private lateinit var email: EditText
    private lateinit var height: EditText
    private lateinit var goal: EditText
    private lateinit var calorieGoal: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId < 0) { finish(); return }

        db = DatabaseHelper(this)
        name = findViewById(R.id.etFullName)
        email = findViewById(R.id.etEmail)
        height = findViewById(R.id.etHeight)
        goal = findViewById(R.id.etGoalWeight)
        calorieGoal = findViewById(R.id.etCalorieGoal)

        db.getProfile(userId)?.let {
            findViewById<TextView>(R.id.tvProfileUsername).text = "@${it.username}"
            name.setText(it.fullName)
            email.setText(it.email)
            height.setText(it.heightInches?.toString().orEmpty())
            goal.setText(it.goalWeight?.toString().orEmpty())
            calorieGoal.setText(it.calorieGoal?.toString().orEmpty())
        }
        findViewById<Button>(R.id.btnSaveProfile).setOnClickListener { save() }
    }

    private fun save() {
        val emailText = email.text.toString().trim()
        val heightValue = height.text.toString().toDoubleOrNull()
        val goalValue = goal.text.toString().toDoubleOrNull()
        val calorieValue = calorieGoal.text.toString().toIntOrNull()

        if (emailText.isNotEmpty() && !Patterns.EMAIL_ADDRESS.matcher(emailText).matches()) {
            email.error = "Enter a valid email"
            return
        }
        if (height.text.isNotBlank() && (heightValue == null || heightValue !in 36.0..96.0)) {
            height.error = "Enter 36–96 inches"
            return
        }
        if (goal.text.isNotBlank() && (goalValue == null || goalValue !in 50.0..700.0)) {
            goal.error = "Enter 50–700 lb"
            return
        }
        if (calorieGoal.text.isNotBlank() && (calorieValue == null || calorieValue !in 800..6000)) {
            calorieGoal.error = "Enter 800–6000 calories"
            return
        }

        val saved = db.updateProfile(
            userId,
            name.text.toString(),
            emailText,
            heightValue,
            goalValue,
            calorieValue
        )
        if (saved) {
            Toast.makeText(this, "Profile and goals saved", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, "Profile could not be saved", Toast.LENGTH_SHORT).show()
        }
    }
}
