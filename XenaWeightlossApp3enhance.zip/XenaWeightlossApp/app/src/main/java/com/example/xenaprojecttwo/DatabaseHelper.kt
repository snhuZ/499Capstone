package com.example.xenaprojecttwo

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class UserProfile(
    val username: String,
    val fullName: String,
    val email: String,
    val heightInches: Double?,
    val goalWeight: Double?,
    val calorieGoal: Int?
)

data class WeightEntry(val date: String, val weight: Double)

data class HealthRecord(
    val id: Long,
    val date: String,
    val weight: Double,
    val bmi: Double?,
    val calories: Int?
)

// Third enchancement: SQLite tables, migrations, relationships, and CRUD. //
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        createUsersTable(db)
        createWeightsTable(db)
        createHealthTables(db)
        createIndexes(db)
    }

    private fun createUsersTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE $TABLE_USERS (
            $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_USERNAME TEXT UNIQUE COLLATE NOCASE NOT NULL,
            $COLUMN_PASSWORD TEXT NOT NULL,
            $COLUMN_PASSWORD_SALT TEXT,
            $COLUMN_FULL_NAME TEXT NOT NULL DEFAULT '',
            $COLUMN_EMAIL TEXT NOT NULL DEFAULT '',
            $COLUMN_HEIGHT REAL CHECK($COLUMN_HEIGHT IS NULL OR $COLUMN_HEIGHT BETWEEN 36 AND 96),
            $COLUMN_GOAL_WEIGHT REAL CHECK($COLUMN_GOAL_WEIGHT IS NULL OR $COLUMN_GOAL_WEIGHT BETWEEN 50 AND 700),
            $COLUMN_CALORIE_GOAL INTEGER CHECK($COLUMN_CALORIE_GOAL IS NULL OR $COLUMN_CALORIE_GOAL BETWEEN 800 AND 6000),
            $COLUMN_CREATED_AT TEXT NOT NULL
        )""")
    }

    private fun createWeightsTable(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE $TABLE_WEIGHTS (
            $COLUMN_WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_WEIGHT_USER_ID INTEGER NOT NULL,
            $COLUMN_WEIGHT_DATE TEXT NOT NULL,
            $COLUMN_WEIGHT_VALUE REAL NOT NULL CHECK($COLUMN_WEIGHT_VALUE BETWEEN 50 AND 1000),
            UNIQUE($COLUMN_WEIGHT_USER_ID, $COLUMN_WEIGHT_DATE),
            FOREIGN KEY($COLUMN_WEIGHT_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID) ON DELETE CASCADE
        )""")
    }

    private fun createHealthTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE $TABLE_BMI_HISTORY (
            $COLUMN_BMI_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_BMI_USER_ID INTEGER NOT NULL,
            $COLUMN_BMI_WEIGHT_ID INTEGER NOT NULL UNIQUE,
            $COLUMN_BMI_DATE TEXT NOT NULL,
            $COLUMN_BMI_VALUE REAL NOT NULL CHECK($COLUMN_BMI_VALUE BETWEEN 5 AND 100),
            FOREIGN KEY($COLUMN_BMI_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID) ON DELETE CASCADE,
            FOREIGN KEY($COLUMN_BMI_WEIGHT_ID) REFERENCES $TABLE_WEIGHTS($COLUMN_WEIGHT_ID) ON DELETE CASCADE
        )""")
        db.execSQL("""CREATE TABLE $TABLE_CALORIE_LOGS (
            $COLUMN_CALORIE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_CALORIE_USER_ID INTEGER NOT NULL,
            $COLUMN_CALORIE_DATE TEXT NOT NULL,
            $COLUMN_CALORIES INTEGER NOT NULL CHECK($COLUMN_CALORIES BETWEEN 0 AND 15000),
            UNIQUE($COLUMN_CALORIE_USER_ID, $COLUMN_CALORIE_DATE),
            FOREIGN KEY($COLUMN_CALORIE_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID) ON DELETE CASCADE
        )""")
    }

    private fun createIndexes(db: SQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_weights_user_date ON $TABLE_WEIGHTS($COLUMN_WEIGHT_USER_ID, $COLUMN_WEIGHT_DATE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_bmi_user_date ON $TABLE_BMI_HISTORY($COLUMN_BMI_USER_ID, $COLUMN_BMI_DATE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_calories_user_date ON $TABLE_CALORIE_LOGS($COLUMN_CALORIE_USER_ID, $COLUMN_CALORIE_DATE)")
    }

    //Preserves existing data
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_PASSWORD_SALT TEXT")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_FULL_NAME TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_EMAIL TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_HEIGHT REAL")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_GOAL_WEIGHT REAL")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_CREATED_AT TEXT NOT NULL DEFAULT ''")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_CALORIE_GOAL INTEGER")
            // Keep the newest record if an older database contains duplicate dates.
            db.execSQL("""DELETE FROM $TABLE_WEIGHTS WHERE $COLUMN_WEIGHT_ID NOT IN (
                SELECT MAX($COLUMN_WEIGHT_ID) FROM $TABLE_WEIGHTS
                GROUP BY $COLUMN_WEIGHT_USER_ID, $COLUMN_WEIGHT_DATE
            )""")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_weights_unique_day ON $TABLE_WEIGHTS($COLUMN_WEIGHT_USER_ID, $COLUMN_WEIGHT_DATE)")
            createHealthTables(db)
            createIndexes(db)
            // Backfill BMI history when an existing user already has a valid height.
            db.execSQL("""INSERT OR IGNORE INTO $TABLE_BMI_HISTORY
                ($COLUMN_BMI_USER_ID, $COLUMN_BMI_WEIGHT_ID, $COLUMN_BMI_DATE, $COLUMN_BMI_VALUE)
                SELECT w.$COLUMN_WEIGHT_USER_ID, w.$COLUMN_WEIGHT_ID, w.$COLUMN_WEIGHT_DATE,
                    703.0 * w.$COLUMN_WEIGHT_VALUE / (u.$COLUMN_HEIGHT * u.$COLUMN_HEIGHT)
                FROM $TABLE_WEIGHTS w JOIN $TABLE_USERS u
                    ON u.$COLUMN_USER_ID = w.$COLUMN_WEIGHT_USER_ID
                WHERE u.$COLUMN_HEIGHT BETWEEN 36 AND 96
                  AND (703.0 * w.$COLUMN_WEIGHT_VALUE / (u.$COLUMN_HEIGHT * u.$COLUMN_HEIGHT)) BETWEEN 5 AND 100""")
        }
    }

    fun usernameExists(username: String): Boolean = readableDatabase.query(
        TABLE_USERS,
        arrayOf(COLUMN_USER_ID),
        "$COLUMN_USERNAME=?",
        arrayOf(username.trim()),
        null,
        null,
        null
    ).use { it.moveToFirst() }

    fun authenticate(username: String, password: String): Int {
        readableDatabase.query(
            TABLE_USERS,
            arrayOf(COLUMN_USER_ID, COLUMN_PASSWORD, COLUMN_PASSWORD_SALT),
            "$COLUMN_USERNAME=?",
            arrayOf(username.trim()),
            null,
            null,
            null
        ).use { cursor ->
            if (!cursor.moveToFirst()) return -1
            val id = cursor.getInt(0)
            val saved = cursor.getString(1)
            val salt = cursor.getString(2)
            val valid = if (salt.isNullOrBlank()) {
                MessageDigest.isEqual(saved.toByteArray(), password.toByteArray())
            } else {
                MessageDigest.isEqual(saved.hexToBytes(), hashPassword(password, salt.hexToBytes()))
            }
            if (!valid) return -1
            if (salt.isNullOrBlank()) updatePasswordHash(id, password)
            return id
        }
    }

    fun createUser(username: String, password: String): Int {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username.trim())
            put(COLUMN_PASSWORD, hashPassword(password, salt).toHex())
            put(COLUMN_PASSWORD_SALT, salt.toHex())
            put(COLUMN_CREATED_AT, now())
        }
        return writableDatabase.insert(TABLE_USERS, null, values).toInt()
    }

    private fun updatePasswordHash(userId: Int, password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        writableDatabase.update(
            TABLE_USERS,
            ContentValues().apply {
                put(COLUMN_PASSWORD, hashPassword(password, salt).toHex())
                put(COLUMN_PASSWORD_SALT, salt.toHex())
            },
            "$COLUMN_USER_ID=?",
            arrayOf(userId.toString())
        )
    }

    fun getProfile(userId: Int): UserProfile? = readableDatabase.query(
        TABLE_USERS,
        arrayOf(
            COLUMN_USERNAME,
            COLUMN_FULL_NAME,
            COLUMN_EMAIL,
            COLUMN_HEIGHT,
            COLUMN_GOAL_WEIGHT,
            COLUMN_CALORIE_GOAL
        ),
        "$COLUMN_USER_ID=?",
        arrayOf(userId.toString()),
        null,
        null,
        null
    ).use { c ->
        if (!c.moveToFirst()) null else UserProfile(
            c.getString(0),
            c.getString(1),
            c.getString(2),
            if (c.isNull(3)) null else c.getDouble(3),
            if (c.isNull(4)) null else c.getDouble(4),
            if (c.isNull(5)) null else c.getInt(5)
        )
    }

    fun updateProfile(
        userId: Int,
        fullName: String,
        email: String,
        height: Double?,
        goalWeight: Double?,
        calorieGoal: Int?
    ): Boolean {
        if (!DatabaseValidation.validProfile(height, goalWeight, calorieGoal)) return false
        val db = writableDatabase
        return db.inTransaction {
            val changed = update(
                TABLE_USERS,
                ContentValues().apply {
                    put(COLUMN_FULL_NAME, fullName.trim())
                    put(COLUMN_EMAIL, email.trim())
                    putNullable(COLUMN_HEIGHT, height)
                    putNullable(COLUMN_GOAL_WEIGHT, goalWeight)
                    putNullable(COLUMN_CALORIE_GOAL, calorieGoal)
                },
                "$COLUMN_USER_ID=?",
                arrayOf(userId.toString())
            ) > 0
            if (height != null) {
                rebuildBmiHistory(this, userId, height)
            } else {
                delete(TABLE_BMI_HISTORY, "$COLUMN_BMI_USER_ID=?", arrayOf(userId.toString()))
            }
            changed
        }
    }

    // Inserts a weight, BMI snapshot, and optional calorie log as one transaction.
    fun addHealthRecord(userId: Int, date: String, weight: Double, calories: Int?): Long {
        if (!DatabaseValidation.validHealthRecord(date, weight, calories)) return -1L
        return writableDatabase.inTransaction {
            val weightId = insert(
                TABLE_WEIGHTS,
                null,
                ContentValues().apply {
                    put(COLUMN_WEIGHT_USER_ID, userId)
                    put(COLUMN_WEIGHT_DATE, date)
                    put(COLUMN_WEIGHT_VALUE, weight)
                }
            )
            if (weightId == -1L) return@inTransaction -1L
            syncBmi(this, userId, weightId, date, weight)
            syncCalories(this, userId, date, calories)
            weightId
        }
    }

    // Maintains related BMI and calorie rows when a weight entry changes.
    fun updateHealthRecord(recordId: Long, userId: Int, date: String, weight: Double, calories: Int?): Boolean {
        if (!DatabaseValidation.validHealthRecord(date, weight, calories)) return false
        return writableDatabase.inTransaction {
            val oldDate = query(
                TABLE_WEIGHTS,
                arrayOf(COLUMN_WEIGHT_DATE),
                "$COLUMN_WEIGHT_ID=? AND $COLUMN_WEIGHT_USER_ID=?",
                arrayOf(recordId.toString(), userId.toString()),
                null,
                null,
                null
            ).use { if (it.moveToFirst()) it.getString(0) else null } ?: return@inTransaction false

            val updated = updateWithOnConflict(
                TABLE_WEIGHTS,
                ContentValues().apply {
                    put(COLUMN_WEIGHT_DATE, date)
                    put(COLUMN_WEIGHT_VALUE, weight)
                },
                "$COLUMN_WEIGHT_ID=? AND $COLUMN_WEIGHT_USER_ID=?",
                arrayOf(recordId.toString(), userId.toString()),
                SQLiteDatabase.CONFLICT_IGNORE
            ) > 0
            if (!updated) return@inTransaction false
            syncBmi(this, userId, recordId, date, weight)
            if (oldDate != date) {
                delete(
                    TABLE_CALORIE_LOGS,
                    "$COLUMN_CALORIE_USER_ID=? AND $COLUMN_CALORIE_DATE=?",
                    arrayOf(userId.toString(), oldDate)
                )
            }
            syncCalories(this, userId, date, calories)
            true
        }
    }

    fun deleteHealthRecord(recordId: Long, userId: Int): Boolean = writableDatabase.inTransaction {
        val date = query(
            TABLE_WEIGHTS,
            arrayOf(COLUMN_WEIGHT_DATE),
            "$COLUMN_WEIGHT_ID=? AND $COLUMN_WEIGHT_USER_ID=?",
            arrayOf(recordId.toString(), userId.toString()),
            null,
            null,
            null
        ).use { if (it.moveToFirst()) it.getString(0) else null } ?: return@inTransaction false
        val deleted = delete(
            TABLE_WEIGHTS,
            "$COLUMN_WEIGHT_ID=? AND $COLUMN_WEIGHT_USER_ID=?",
            arrayOf(recordId.toString(), userId.toString())
        ) > 0
        delete(
            TABLE_CALORIE_LOGS,
            "$COLUMN_CALORIE_USER_ID=? AND $COLUMN_CALORIE_DATE=?",
            arrayOf(userId.toString(), date)
        )
        deleted
    }

    // Date filtering and supports indexed search.
    fun searchHealthRecords(userId: Int, fromDate: String?, toDate: String?): List<HealthRecord> {
        val conditions = mutableListOf("w.$COLUMN_WEIGHT_USER_ID=?")
        val args = mutableListOf(userId.toString())
        if (!fromDate.isNullOrBlank()) {
            conditions += "w.$COLUMN_WEIGHT_DATE>=?"
            args += fromDate
        }
        if (!toDate.isNullOrBlank()) {
            conditions += "w.$COLUMN_WEIGHT_DATE<=?"
            args += toDate
        }
        val sql = """SELECT w.$COLUMN_WEIGHT_ID, w.$COLUMN_WEIGHT_DATE, w.$COLUMN_WEIGHT_VALUE,
            b.$COLUMN_BMI_VALUE, c.$COLUMN_CALORIES
            FROM $TABLE_WEIGHTS w
            LEFT JOIN $TABLE_BMI_HISTORY b ON b.$COLUMN_BMI_WEIGHT_ID=w.$COLUMN_WEIGHT_ID
            LEFT JOIN $TABLE_CALORIE_LOGS c
                ON c.$COLUMN_CALORIE_USER_ID=w.$COLUMN_WEIGHT_USER_ID
                AND c.$COLUMN_CALORIE_DATE=w.$COLUMN_WEIGHT_DATE
            WHERE ${conditions.joinToString(" AND ")}
            ORDER BY w.$COLUMN_WEIGHT_DATE DESC"""
        return readableDatabase.rawQuery(sql, args.toTypedArray()).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(
                        HealthRecord(
                            cursor.getLong(0),
                            cursor.getString(1),
                            cursor.getDouble(2),
                            if (cursor.isNull(3)) null else cursor.getDouble(3),
                            if (cursor.isNull(4)) null else cursor.getInt(4)
                        )
                    )
                }
            }
        }
    }

    fun addWeight(userId: Int, date: String, weight: Double): Boolean =
        addHealthRecord(userId, date, weight, null) != -1L

    fun getAllWeightsForUser(userId: Int): Cursor = readableDatabase.rawQuery(
        "SELECT $COLUMN_WEIGHT_DATE, $COLUMN_WEIGHT_VALUE FROM $TABLE_WEIGHTS WHERE $COLUMN_WEIGHT_USER_ID=? ORDER BY $COLUMN_WEIGHT_DATE ASC",
        arrayOf(userId.toString())
    )

    fun getWeightEntries(userId: Int): List<WeightEntry> = getAllWeightsForUser(userId).use { c ->
        buildList {
            while (c.moveToNext()) add(WeightEntry(c.getString(0), c.getDouble(1)))
        }
    }

    private fun syncBmi(db: SQLiteDatabase, userId: Int, weightId: Long, date: String, weight: Double) {
        val height = getProfileHeight(db, userId)
        if (height == null) {
            db.delete(TABLE_BMI_HISTORY, "$COLUMN_BMI_WEIGHT_ID=?", arrayOf(weightId.toString()))
            return
        }
        val bmi = 703.0 * weight / (height * height)
        if (bmi !in 5.0..100.0) {
            db.delete(TABLE_BMI_HISTORY, "$COLUMN_BMI_WEIGHT_ID=?", arrayOf(weightId.toString()))
            return
        }
        db.insertWithOnConflict(
            TABLE_BMI_HISTORY,
            null,
            ContentValues().apply {
                put(COLUMN_BMI_USER_ID, userId)
                put(COLUMN_BMI_WEIGHT_ID, weightId)
                put(COLUMN_BMI_DATE, date)
                put(COLUMN_BMI_VALUE, bmi)
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    private fun syncCalories(db: SQLiteDatabase, userId: Int, date: String, calories: Int?) {
        if (calories == null) {
            db.delete(
                TABLE_CALORIE_LOGS,
                "$COLUMN_CALORIE_USER_ID=? AND $COLUMN_CALORIE_DATE=?",
                arrayOf(userId.toString(), date)
            )
            return
        }
        db.insertWithOnConflict(
            TABLE_CALORIE_LOGS,
            null,
            ContentValues().apply {
                put(COLUMN_CALORIE_USER_ID, userId)
                put(COLUMN_CALORIE_DATE, date)
                put(COLUMN_CALORIES, calories)
            },
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    private fun rebuildBmiHistory(db: SQLiteDatabase, userId: Int, height: Double) {
        db.delete(TABLE_BMI_HISTORY, "$COLUMN_BMI_USER_ID=?", arrayOf(userId.toString()))
        db.rawQuery(
            "SELECT $COLUMN_WEIGHT_ID, $COLUMN_WEIGHT_DATE, $COLUMN_WEIGHT_VALUE FROM $TABLE_WEIGHTS WHERE $COLUMN_WEIGHT_USER_ID=?",
            arrayOf(userId.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val weightId = cursor.getLong(0)
                val date = cursor.getString(1)
                val weight = cursor.getDouble(2)
                val bmi = 703.0 * weight / (height * height)
                if (bmi !in 5.0..100.0) continue
                db.insert(
                    TABLE_BMI_HISTORY,
                    null,
                    ContentValues().apply {
                        put(COLUMN_BMI_USER_ID, userId)
                        put(COLUMN_BMI_WEIGHT_ID, weightId)
                        put(COLUMN_BMI_DATE, date)
                        put(COLUMN_BMI_VALUE, bmi)
                    }
                )
            }
        }
    }

    private fun getProfileHeight(db: SQLiteDatabase, userId: Int): Double? = db.query(
        TABLE_USERS,
        arrayOf(COLUMN_HEIGHT),
        "$COLUMN_USER_ID=?",
        arrayOf(userId.toString()),
        null,
        null,
        null
    ).use { cursor ->
        if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getDouble(0) else null
    }

    private fun hashPassword(password: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(password.toCharArray(), salt, 120_000, 256)).encoded

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    private fun ContentValues.putNullable(key: String, value: Double?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun ContentValues.putNullable(key: String, value: Int?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private inline fun <T> SQLiteDatabase.inTransaction(block: SQLiteDatabase.() -> T): T {
        beginTransaction()
        return try {
            val result = block()
            setTransactionSuccessful()
            result
        } finally {
            endTransaction()
        }
    }

    companion object {
        private const val DATABASE_NAME = "weight_tracker.db"
        private const val DATABASE_VERSION = 3

        const val TABLE_USERS = "users"
        const val COLUMN_USER_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"
        const val COLUMN_PASSWORD_SALT = "password_salt"
        const val COLUMN_FULL_NAME = "full_name"
        const val COLUMN_EMAIL = "email"
        const val COLUMN_HEIGHT = "height_inches"
        const val COLUMN_GOAL_WEIGHT = "goal_weight"
        const val COLUMN_CALORIE_GOAL = "calorie_goal"
        const val COLUMN_CREATED_AT = "created_at"

        const val TABLE_WEIGHTS = "weights"
        const val COLUMN_WEIGHT_ID = "id"
        const val COLUMN_WEIGHT_USER_ID = "user_id"
        const val COLUMN_WEIGHT_DATE = "date"
        const val COLUMN_WEIGHT_VALUE = "weight"

        const val TABLE_BMI_HISTORY = "bmi_history"
        const val COLUMN_BMI_ID = "id"
        const val COLUMN_BMI_USER_ID = "user_id"
        const val COLUMN_BMI_WEIGHT_ID = "weight_id"
        const val COLUMN_BMI_DATE = "date"
        const val COLUMN_BMI_VALUE = "bmi"

        const val TABLE_CALORIE_LOGS = "calorie_logs"
        const val COLUMN_CALORIE_ID = "id"
        const val COLUMN_CALORIE_USER_ID = "user_id"
        const val COLUMN_CALORIE_DATE = "date"
        const val COLUMN_CALORIES = "calories"
    }
}
