package com.example.xenaprojecttwo

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

//Validation rules
object DatabaseValidation {
    fun validDate(value: String): Boolean {
        if (!value.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return false
        return try {
            val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                isLenient = false
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val parsed = formatter.parse(value)
            parsed != null && formatter.format(parsed) == value
        } catch (_: Exception) {
            false
        }
    }

    fun validHealthRecord(date: String, weight: Double, calories: Int?): Boolean =
        validDate(date) && weight in 50.0..1000.0 && (calories == null || calories in 0..15000)

    fun validProfile(height: Double?, goalWeight: Double?, calorieGoal: Int?): Boolean =
        (height == null || height in 36.0..96.0) &&
            (goalWeight == null || goalWeight in 50.0..700.0) &&
            (calorieGoal == null || calorieGoal in 800..6000)

    fun validDateRange(fromDate: String?, toDate: String?): Boolean {
        if (!fromDate.isNullOrBlank() && !validDate(fromDate)) return false
        if (!toDate.isNullOrBlank() && !validDate(toDate)) return false
        return fromDate.isNullOrBlank() || toDate.isNullOrBlank() || fromDate <= toDate
    }
}
