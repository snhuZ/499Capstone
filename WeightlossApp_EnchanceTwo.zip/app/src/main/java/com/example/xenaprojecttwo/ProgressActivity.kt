package com.example.xenaprojecttwo

import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.math.roundToInt

// Makes user weight history into a chart and algorithm driven progress report.
class ProgressActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        val userId = intent.getIntExtra("USER_ID", -1)
        if (userId < 0) { finish(); return }

        val database = DatabaseHelper(this)
        val entries = database.getWeightEntries(userId)
        val profile = database.getProfile(userId)
        findViewById<ProgressChartView>(R.id.progressChart).entries = entries

        // Second Enhancement: calculates all progress information by going through the user’s weight records

        val report = ProgressAnalyzer().analyze(entries, profile?.heightInches, profile?.goalWeight)
        displayTransformationSummary(entries)
        displayAlgorithmResults(report, profile?.goalWeight)
    }

    private fun displayTransformationSummary(entries: List<WeightEntry>) {
        val summary = findViewById<TextView>(R.id.tvProgressSummary)
        if (entries.isEmpty()) {
            summary.text = "No weight entries yet. Add a weight from the dashboard to begin."
            return
        }
        val first = entries.first().weight
        val current = entries.last().weight
        val change = current - first
        val direction = when { change < 0 -> "lost"; change > 0 -> "gained"; else -> "maintained" }
        summary.text = "Starting: %.1f lb\nCurrent: %.1f lb\nYou have %s %.1f lb across %d entries."
            .format(first, current, direction, abs(change), entries.size)
    }

    private fun displayAlgorithmResults(report: ProgressAnalyzer.Report, goalWeight: Double?) {
        findViewById<TextView>(R.id.tvBmi).text = report.bmi?.let {
            "BMI: %.1f — %s".format(it, report.bmiCategory)
        } ?: "BMI: ${report.bmiCategory}"

        findViewById<TextView>(R.id.tvWeeklyAverage).text = report.sevenDayAverage?.let {
            "7-day average: %.1f lb".format(it)
        } ?: "7-day average: Add weight entries"

        val progress = report.progressPercent
        findViewById<ProgressBar>(R.id.goalProgressBar).progress = progress?.roundToInt() ?: 0
        findViewById<TextView>(R.id.tvGoalProgress).text = when {
            goalWeight == null -> "Goal progress: Add a goal weight in your profile"
            progress == null -> "Goal progress: Starting weight already equals the goal"
            else -> "Goal progress: %.1f%% toward %.1f lb".format(progress, goalWeight)
        }

        val trendLabel = when (report.trend) {
            ProgressAnalyzer.Trend.LOSING -> "Losing"
            ProgressAnalyzer.Trend.GAINING -> "Gaining"
            ProgressAnalyzer.Trend.MAINTAINING -> "Maintaining"
            ProgressAnalyzer.Trend.INSUFFICIENT_DATA -> "More dated entries needed"
        }
        findViewById<TextView>(R.id.tvTrend).text = report.weeklyRate?.let {
            "Trend: $trendLabel (%+.2f lb/week)".format(it)
        } ?: "Trend: $trendLabel"

        findViewById<TextView>(R.id.tvGoalEstimate).text = report.estimatedGoalDate?.let {
            "Estimated goal date: $it"
        } ?: "Estimated goal date: Not available until the trend moves toward the goal"

        findViewById<TextView>(R.id.tvReminder).text = "Smart reminder: ${report.reminder}"
    }
}
