package com.example.xenaprojecttwo

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.ceil

/**
 * Second Enhancement
 *
 * Calculates health information from the user's weight records.
 */
class ProgressAnalyzer {

    enum class Trend { LOSING, GAINING, MAINTAINING, INSUFFICIENT_DATA }

    data class Report(
        val currentWeight: Double?,
        val bmi: Double?,
        val bmiCategory: String,
        val sevenDayAverage: Double?,
        val progressPercent: Double?,
        val trend: Trend,
        val weeklyRate: Double?,
        val estimatedGoalDate: String?,
        val reminder: String,
        val validEntryCount: Int
    )

    private data class DatedWeight(val date: Date, val weight: Double)

    // Processed in chronological order for calculations.

    fun analyze(
        entries: List<WeightEntry>,
        heightInches: Double?,
        goalWeight: Double?,
        todayText: String = formatDate(Date())
    ): Report {
        val datedWeights = entries.mapNotNull { entry ->
            parseDate(entry.date)?.let { DatedWeight(it, entry.weight) }
        }.sortedBy { it.date }

        if (datedWeights.isEmpty()) {
            return Report(null, null, "Height and weight required", null, null,
                Trend.INSUFFICIENT_DATA, null, null,
                "Add your first weight entry to begin progress analysis.", 0)
        }

        val current = datedWeights.last().weight
        val bmi = calculateBmi(current, heightInches)
        val weeklyAverage = calculateSevenDayAverage(datedWeights)
        val progress = calculateProgress(datedWeights.first().weight, current, goalWeight)
        val slopePerDay = calculateRegressionSlope(datedWeights)
        val weeklyRate = slopePerDay?.times(7.0)
        val trend = classifyTrend(weeklyRate)
        val estimate = estimateGoalDate(
            datedWeights.last().date,
            datedWeights.first().weight,
            current,
            goalWeight,
            slopePerDay
        )
        val today = parseDate(todayText) ?: Date()

        return Report(
            currentWeight = current,
            bmi = bmi,
            bmiCategory = classifyBmi(bmi),
            sevenDayAverage = weeklyAverage,
            progressPercent = progress,
            trend = trend,
            weeklyRate = weeklyRate,
            estimatedGoalDate = estimate,
            reminder = buildReminder(datedWeights.last().date, today),
            validEntryCount = datedWeights.size
        )
    }

    // BMI calculated with  weight / height² × 703. In lbs and inches
    private fun calculateBmi(weight: Double, heightInches: Double?): Double? {
        if (heightInches == null || heightInches <= 0.0) return null
        return weight * 703.0 / (heightInches * heightInches)
    }

    private fun classifyBmi(bmi: Double?): String = when {
        bmi == null -> "Add height in your profile"
        bmi < 18.5 -> "Underweight"
        bmi < 25.0 -> "Healthy range"
        bmi < 30.0 -> "Overweight"
        else -> "Obesity range"
    }

    // Average of the last several entries
    private fun calculateSevenDayAverage(entries: List<DatedWeight>): Double {
        val newest = entries.last().date.time
        val windowStart = newest - SIX_DAYS_MS
        val window = ArrayDeque<Double>()
        entries.forEach { if (it.date.time >= windowStart) window.addLast(it.weight) }
        return window.average()
    }

    // Progress towards goal weight. Between 0 and 100 so that negative values can not be created in the app and percentage can't go past 100.
    private fun calculateProgress(start: Double, current: Double, goal: Double?): Double? {
        if (goal == null || abs(start - goal) < EPSILON) return null
        val raw = (current - start) / (goal - start) * 100.0
        return raw.coerceIn(0.0, 100.0)
    }

    // Creates slope of average change in weight across all records entered by user
    private fun calculateRegressionSlope(entries: List<DatedWeight>): Double? {
        if (entries.size < 2) return null
        val origin = entries.first().date.time
        val points = entries.map { ((it.date.time - origin).toDouble() / DAY_MS.toDouble()) to it.weight }
        if (points.map { it.first }.distinct().size < 2) return null
        val meanX = points.map { it.first }.average()
        val meanY = points.map { it.second }.average()
        val numerator = points.sumOf { (it.first - meanX) * (it.second - meanY) }
        val denominator = points.sumOf { (it.first - meanX) * (it.first - meanX) }
        return if (abs(denominator) < EPSILON) null else numerator / denominator
    }

    private fun classifyTrend(weeklyRate: Double?): Trend = when {
        weeklyRate == null -> Trend.INSUFFICIENT_DATA
        weeklyRate < -MAINTAIN_THRESHOLD -> Trend.LOSING
        weeklyRate > MAINTAIN_THRESHOLD -> Trend.GAINING
        else -> Trend.MAINTAINING
    }

    // Predicts when user might reach goal weight using change in weight per day.
    private fun estimateGoalDate(
        lastDate: Date,
        start: Double,
        current: Double,
        goal: Double?,
        slopePerDay: Double?
    ): String? {
        if (goal == null) return null
        val goalReached = if (start > goal) current <= goal else current >= goal
        if (goalReached || abs(current - goal) < EPSILON) return formatDate(lastDate)
        if (slopePerDay == null || abs(slopePerDay) < MIN_DAILY_RATE) return null
        val days = (goal - current) / slopePerDay
        if (days <= 0.0 || days > MAX_PREDICTION_DAYS) return null
        return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            time = lastDate
            add(Calendar.DAY_OF_YEAR, ceil(days).toInt())
        }.time.let(::formatDate)
    }

    //Reminder based on last date of entry without making user feel guilty for missed entries
    private fun buildReminder(lastEntry: Date, today: Date): String {
        val days = ((today.time - lastEntry.time) / DAY_MS).coerceAtLeast(0L)
        return when {
            days == 0L -> "Great job staying on track! Check in again tomorrow"
            days == 1L -> "Ready for today’s check-in? Add your weight whenever you’re ready!"
            days >= 7L -> "How are you doing? Add a new weight entry to refresh your progress"
            else -> "It’s been $days days since your last check-in. Add an entry when you’re ready."
        }
    }

    companion object {
        private const val DAY_MS = 86_400_000L
        private const val SIX_DAYS_MS = 6L * DAY_MS
        private const val EPSILON = 0.000001
        private const val MAINTAIN_THRESHOLD = 0.10 // pounds per week
        private const val MIN_DAILY_RATE = 0.01
        private const val MAX_PREDICTION_DAYS = 3650.0

        private fun formatter() = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            isLenient = false
            timeZone = TimeZone.getTimeZone("UTC")
        }
        private fun parseDate(value: String): Date? = try {
            val parsed = formatter().parse(value)
            if (parsed != null && formatter().format(parsed) == value) parsed else null
        } catch (_: Exception) {
            null
        }
        private fun formatDate(date: Date): String = formatter().format(date)
    }
}
