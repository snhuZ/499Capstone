package com.example.xenaprojecttwo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
//login and account creation are separated now.
class MainActivity : AppCompatActivity() {
    private lateinit var username: EditText; private lateinit var password: EditText
    private lateinit var message: TextView; private lateinit var db: DatabaseHelper
    private var failedAttempts = 0; private var lockedUntil = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        db = DatabaseHelper(this); username = findViewById(R.id.etUsername); password = findViewById(R.id.etPassword)
        message = findViewById(R.id.tvAuthMessage)
        findViewById<Button>(R.id.btnLogin).setOnClickListener { signIn() }
        findViewById<Button>(R.id.btnCreateAccount).setOnClickListener { register() }
    }
    // Blocks too many password attempts.
    private fun signIn() {
        if (System.currentTimeMillis() < lockedUntil) { showError("Too many attempts. Try again in 30 seconds."); return }
        val name = username.text.toString().trim(); val pass = password.text.toString()
        if (name.isBlank() || pass.isBlank()) { showError("Enter your username and password."); return }
        val userId = db.authenticate(name, pass)
        if (userId >= 0) { failedAttempts = 0; openDashboard(userId) }
        else {
            failedAttempts++
            if (failedAttempts >= 5) { lockedUntil = System.currentTimeMillis() + 30_000; failedAttempts = 0 }
            showError("Incorrect username or password.")
        }
    }
    // User account creation after passing validation.
    private fun register() {
        val name = username.text.toString().trim(); val pass = password.text.toString()
        val error = validate(name, pass)
        if (error != null) { showError(error); return }
        if (db.usernameExists(name)) { showError("That username is already registered. Choose Sign In."); return }
        val id = db.createUser(name, pass)
        if (id >= 0) { Toast.makeText(this, "Account created securely", Toast.LENGTH_SHORT).show(); openDashboard(id) }
        else showError("Account could not be created.")
    }
    // Password and username rules to make stronger passwords
    private fun validate(name: String, pass: String): String? = when {
        name.length !in 3..30 -> "Username must contain 3–30 characters."
        !name.matches(Regex("[A-Za-z0-9._-]+")) -> "Username may use letters, numbers, dots, underscores, and hyphens."
        pass.length < 10 -> "Password must contain at least 10 characters."
        !pass.any(Char::isUpperCase) -> "Password needs an uppercase letter."
        !pass.any(Char::isLowerCase) -> "Password needs a lowercase letter."
        !pass.any(Char::isDigit) -> "Password needs a number."
        pass.none { !it.isLetterOrDigit() } -> "Password needs a special character."
        pass.contains(name, ignoreCase = true) -> "Password cannot contain your username."
        else -> null
    }

    private fun showError(text: String) { message.text = text; message.setTextColor(getColor(android.R.color.holo_red_dark)) }
    private fun openDashboard(userId: Int) { startActivity(Intent(this, WeightListActivity::class.java).putExtra("USER_ID", userId)); finish() }
}
