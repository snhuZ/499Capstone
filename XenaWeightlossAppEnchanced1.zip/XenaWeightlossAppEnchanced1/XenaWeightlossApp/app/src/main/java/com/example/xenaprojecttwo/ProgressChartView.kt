package com.example.xenaprojecttwo
// Creation of progress chart for weight changes
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class ProgressChartView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    var entries: List<WeightEntry> = emptyList(); set(value) { field = value; invalidate() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25, 118, 210); strokeWidth = 7f; style = Paint.Style.STROKE }
    private val point = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 143, 0); style = Paint.Style.FILL }
    private val axis = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; strokeWidth = 2f; textSize = 30f }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); val p = 48f
        canvas.drawLine(p, p, p, height-p, axis); canvas.drawLine(p, height-p, width-p, height-p, axis)
        if (entries.isEmpty()) { canvas.drawText("Add at least one weight to see your trend", p+20, height/2f, axis); return }
        val min = entries.minOf { it.weight }; val max = entries.maxOf { it.weight }; val range = (max-min).coerceAtLeast(5.0)
        var lastX = 0f; var lastY = 0f
        entries.forEachIndexed { index, entry ->
            val x = if (entries.size == 1) width/2f else p + index * (width-2*p)/(entries.size-1)
            val y = (height-p - ((entry.weight-min)/range*(height-2*p))).toFloat()
            if (index > 0) canvas.drawLine(lastX, lastY, x, y, line)
            canvas.drawCircle(x, y, 9f, point); lastX=x; lastY=y
        }
        canvas.drawText("${"%.1f".format(max)} lb", p+8, p+26, axis); canvas.drawText("${"%.1f".format(min)} lb", p+8, height-p-10, axis)
    }
}
