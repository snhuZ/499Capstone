package com.example.xenaprojecttwo

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper; private var userId = -1
    private lateinit var name: EditText; private lateinit var email: EditText; private lateinit var height: EditText; private lateinit var goal: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_profile); userId=intent.getIntExtra("USER_ID",-1)
        if(userId<0){finish();return}; db=DatabaseHelper(this)
        name=findViewById(R.id.etFullName); email=findViewById(R.id.etEmail); height=findViewById(R.id.etHeight); goal=findViewById(R.id.etGoalWeight)
        db.getProfile(userId)?.let { findViewById<TextView>(R.id.tvProfileUsername).text="Username: ${it.username}"; name.setText(it.fullName); email.setText(it.email); height.setText(it.heightInches?.toString().orEmpty()); goal.setText(it.goalWeight?.toString().orEmpty()) }
        findViewById<Button>(R.id.btnSaveProfile).setOnClickListener { save() }
    }
    // Restrictions of what can be entered into fields
    private fun save(){
        val emailText=email.text.toString().trim(); val h=height.text.toString().toDoubleOrNull(); val g=goal.text.toString().toDoubleOrNull()
        if(emailText.isNotEmpty()&&!Patterns.EMAIL_ADDRESS.matcher(emailText).matches()){email.error="Enter a valid email";return}
        if(height.text.isNotBlank()&&(h==null||h !in 36.0..96.0)){height.error="Enter 36–96 inches";return}
        if(goal.text.isNotBlank()&&(g==null||g !in 50.0..700.0)){goal.error="Enter 50–700 lb";return}
        if(db.updateProfile(userId,name.text.toString(),emailText,h,g)){Toast.makeText(this,"Profile saved",Toast.LENGTH_SHORT).show();finish()}
    }
}
