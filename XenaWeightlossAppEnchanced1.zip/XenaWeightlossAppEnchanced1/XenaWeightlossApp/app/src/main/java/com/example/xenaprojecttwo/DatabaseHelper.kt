package com.example.xenaprojecttwo

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
//improved security and user profile information
data class UserProfile(val username: String, val fullName: String, val email: String, val heightInches: Double?, val goalWeight: Double?)
data class WeightEntry(val date: String, val weight: Double)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true) }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE $TABLE_USERS (
            $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_USERNAME TEXT UNIQUE COLLATE NOCASE NOT NULL,
            $COLUMN_PASSWORD TEXT NOT NULL,
            $COLUMN_PASSWORD_SALT TEXT,
            $COLUMN_FULL_NAME TEXT NOT NULL DEFAULT '',
            $COLUMN_EMAIL TEXT NOT NULL DEFAULT '',
            $COLUMN_HEIGHT REAL,
            $COLUMN_GOAL_WEIGHT REAL,
            $COLUMN_CREATED_AT TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE $TABLE_WEIGHTS (
            $COLUMN_WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_WEIGHT_USER_ID INTEGER NOT NULL,
            $COLUMN_WEIGHT_DATE TEXT NOT NULL,
            $COLUMN_WEIGHT_VALUE REAL NOT NULL CHECK($COLUMN_WEIGHT_VALUE > 0),
            FOREIGN KEY($COLUMN_WEIGHT_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID) ON DELETE CASCADE
        )""")
        db.execSQL("CREATE INDEX idx_weights_user_date ON $TABLE_WEIGHTS($COLUMN_WEIGHT_USER_ID, $COLUMN_WEIGHT_DATE)")
    }
//move information I have already added without deleting it.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_PASSWORD_SALT TEXT")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_FULL_NAME TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_EMAIL TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_HEIGHT REAL")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_GOAL_WEIGHT REAL")
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COLUMN_CREATED_AT TEXT NOT NULL DEFAULT ''")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_weights_user_date ON $TABLE_WEIGHTS($COLUMN_WEIGHT_USER_ID, $COLUMN_WEIGHT_DATE)")
        }
    }

    fun usernameExists(username: String): Boolean = readableDatabase.query(TABLE_USERS, arrayOf(COLUMN_USER_ID),
        "$COLUMN_USERNAME=?", arrayOf(username.trim()), null, null, null).use { it.moveToFirst() }
//Removed plaintext storing of passwords.
    fun authenticate(username: String, password: String): Int {
        readableDatabase.query(TABLE_USERS, arrayOf(COLUMN_USER_ID, COLUMN_PASSWORD, COLUMN_PASSWORD_SALT),
            "$COLUMN_USERNAME=?", arrayOf(username.trim()), null, null, null).use { cursor ->
            if (!cursor.moveToFirst()) return -1
            val id = cursor.getInt(0)
            val saved = cursor.getString(1)
            val salt = cursor.getString(2)
            val valid = if (salt.isNullOrBlank()) MessageDigest.isEqual(saved.toByteArray(), password.toByteArray())
                        else MessageDigest.isEqual(saved.hexToBytes(), hashPassword(password, salt.hexToBytes()))
            if (!valid) return -1
            if (salt.isNullOrBlank()) updatePasswordHash(id, password)
            return id
        }
    }

    fun createUser(username: String, password: String): Int {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username.trim()); put(COLUMN_PASSWORD, hashPassword(password, salt).toHex())
            put(COLUMN_PASSWORD_SALT, salt.toHex()); put(COLUMN_CREATED_AT, now())
        }
        return writableDatabase.insert(TABLE_USERS, null, values).toInt()
    }

    private fun updatePasswordHash(userId: Int, password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        writableDatabase.update(TABLE_USERS, ContentValues().apply {
            put(COLUMN_PASSWORD, hashPassword(password, salt).toHex()); put(COLUMN_PASSWORD_SALT, salt.toHex())
        }, "$COLUMN_USER_ID=?", arrayOf(userId.toString()))
    }
//Get profile information for authenticated user.
    fun getProfile(userId: Int): UserProfile? = readableDatabase.query(TABLE_USERS,
        arrayOf(COLUMN_USERNAME, COLUMN_FULL_NAME, COLUMN_EMAIL, COLUMN_HEIGHT, COLUMN_GOAL_WEIGHT),
        "$COLUMN_USER_ID=?", arrayOf(userId.toString()), null, null, null).use { c ->
        if (!c.moveToFirst()) null else UserProfile(c.getString(0), c.getString(1), c.getString(2),
            if (c.isNull(3)) null else c.getDouble(3), if (c.isNull(4)) null else c.getDouble(4))
    }
//User can change profile
    fun updateProfile(userId: Int, fullName: String, email: String, height: Double?, goalWeight: Double?): Boolean {
        val values = ContentValues().apply {
            put(COLUMN_FULL_NAME, fullName.trim()); put(COLUMN_EMAIL, email.trim())
            if (height == null) putNull(COLUMN_HEIGHT) else put(COLUMN_HEIGHT, height)
            if (goalWeight == null) putNull(COLUMN_GOAL_WEIGHT) else put(COLUMN_GOAL_WEIGHT, goalWeight)
        }
        return writableDatabase.update(TABLE_USERS, values, "$COLUMN_USER_ID=?", arrayOf(userId.toString())) > 0
    }

    fun addWeight(userId: Int, date: String, weight: Double): Boolean = writableDatabase.insert(TABLE_WEIGHTS, null,
        ContentValues().apply { put(COLUMN_WEIGHT_USER_ID, userId); put(COLUMN_WEIGHT_DATE, date); put(COLUMN_WEIGHT_VALUE, weight) }) != -1L

    fun getAllWeightsForUser(userId: Int): Cursor = readableDatabase.rawQuery(
        "SELECT $COLUMN_WEIGHT_DATE, $COLUMN_WEIGHT_VALUE FROM $TABLE_WEIGHTS WHERE $COLUMN_WEIGHT_USER_ID=? ORDER BY $COLUMN_WEIGHT_DATE ASC",
        arrayOf(userId.toString()))

    fun getWeightEntries(userId: Int): List<WeightEntry> = getAllWeightsForUser(userId).use { c ->
        buildList { while (c.moveToNext()) add(WeightEntry(c.getString(0), c.getDouble(1))) }
    }
    //Hash password for added protection.
    private fun hashPassword(password: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(password.toCharArray(), salt, 120_000, 256)).encoded
    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    companion object {
        private const val DATABASE_NAME = "weight_tracker.db"; private const val DATABASE_VERSION = 2
        const val TABLE_USERS="users"; const val COLUMN_USER_ID="id"; const val COLUMN_USERNAME="username"; const val COLUMN_PASSWORD="password"
        const val COLUMN_PASSWORD_SALT="password_salt"; const val COLUMN_FULL_NAME="full_name"; const val COLUMN_EMAIL="email"
        const val COLUMN_HEIGHT="height_inches"; const val COLUMN_GOAL_WEIGHT="goal_weight"; const val COLUMN_CREATED_AT="created_at"
        const val TABLE_WEIGHTS="weights"; const val COLUMN_WEIGHT_ID="id"; const val COLUMN_WEIGHT_USER_ID="user_id"
        const val COLUMN_WEIGHT_DATE="date"; const val COLUMN_WEIGHT_VALUE="weight"
    }
}
