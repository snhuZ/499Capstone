package com.example.xenaprojecttwo

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.content.Intent
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
//Validates weight and date input before moving to database
class WeightListActivity : AppCompatActivity() {

    private val SMS_PERMISSION_REQUEST = 100

    private lateinit var etDate: EditText
    private lateinit var etWeight: EditText
    private lateinit var btnAdd: Button
    private lateinit var gridWeights: GridView

    private lateinit var dbHelper: DatabaseHelper
    private var userId: Int = -1

    private lateinit var adapter: ArrayAdapter<String>
    private val gridData = ArrayList<String>()

    private val goalWeight = 150.0
    private val phoneNumber = "5551234567"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_list)

        userId = intent.getIntExtra("USER_ID", -1)

        dbHelper = DatabaseHelper(this)

        etDate = findViewById(R.id.etDate)
        etWeight = findViewById(R.id.etWeight)
        btnAdd = findViewById(R.id.btnAdd)
        gridWeights = findViewById(R.id.gridWeights)
        findViewById<Button>(R.id.btnProgress).setOnClickListener { startActivity(Intent(this, ProgressActivity::class.java).putExtra("USER_ID", userId)) }
        findViewById<Button>(R.id.btnProfile).setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java).putExtra("USER_ID", userId)) }

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, gridData)
        gridWeights.adapter = adapter


        loadWeights()

        btnAdd.setOnClickListener {
            addWeight()
        }

        gridWeights.setOnItemLongClickListener { _, _, position, _ ->
            Toast.makeText(
                this,
                "Long-press at position $position (hook for delete/update)",
                Toast.LENGTH_SHORT
            ).show()
            true
        }
    }


    private fun loadWeights() {
        gridData.clear()

        val cursor: Cursor? = dbHelper.getAllWeightsForUser(userId)
        cursor?.use {
            if (it.moveToFirst()) {
                do {
                    val date = it.getString(0)
                    val weight = it.getDouble(1)
                    gridData.add(date)
                    gridData.add(weight.toString())
                } while (it.moveToNext())
            }
        }

        adapter.notifyDataSetChanged()
    }

    private fun addWeight() {
        val date = etDate.text.toString().trim()
        val weightText = etWeight.text.toString().trim()

        if (date.isEmpty() || weightText.isEmpty()) {
            Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show()
            return
        }

        val weight = weightText.toDoubleOrNull()
        if (weight == null || weight !in 50.0..1000.0) {
            etWeight.error = "Enter a weight from 50 to 1000 lb"
            return
        }
        if (!date.matches(Regex("\\d{4}-(0[1-9]|1[0-2])-([0-2]\\d|3[01])"))) {
            etDate.error = "Use yyyy-MM-dd"
            return
        }

        val success = dbHelper.addWeight(userId, date, weight)
        if (success) {
            Toast.makeText(this, "Weight added", Toast.LENGTH_SHORT).show()
            etDate.text.clear()
            etWeight.text.clear()
            loadWeights()

            val savedGoal = dbHelper.getProfile(userId)?.goalWeight ?: goalWeight
            if (weight <= savedGoal) {
                handleGoalReached(weight)
            }
        } else {
            Toast.makeText(this, "Error adding weight", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleGoalReached(weight: Double) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            sendGoalSms(weight)
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_REQUEST
            )
        }
    }

    private fun sendGoalSms(weight: Double) {
        val message = "Congrats! You reached your goal weight: $weight"

        try {
            val smsManager = applicationContext.getSystemService(SmsManager::class.java)
            smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
            )
            Toast.makeText(this, "Goal SMS sent", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(
                    this,
                    "SMS permission granted. Goal alerts will be sent as text messages.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "SMS permission denied. App will still function without SMS alerts.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
