package com.example.xenaprojecttwo

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
//Makes user weight history into chart
class ProgressActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_progress)
        val userId = intent.getIntExtra("USER_ID", -1); if (userId < 0) { finish(); return }
        val entries = DatabaseHelper(this).getWeightEntries(userId)
        findViewById<ProgressChartView>(R.id.progressChart).entries = entries
        val summary = findViewById<TextView>(R.id.tvProgressSummary)
        if (entries.isEmpty()) summary.text = "No weight entries yet. Add a weight from the dashboard to begin."
        else {
            val first=entries.first().weight; val current=entries.last().weight; val change=current-first
            val direction = when { change < 0 -> "lost"; change > 0 -> "gained"; else -> "maintained" }
            summary.text = "Starting: %.1f lb\nCurrent: %.1f lb\nYou have %s %.1f lb across %d entries.".format(first,current,direction,abs(change),entries.size)
        }
    }
}
