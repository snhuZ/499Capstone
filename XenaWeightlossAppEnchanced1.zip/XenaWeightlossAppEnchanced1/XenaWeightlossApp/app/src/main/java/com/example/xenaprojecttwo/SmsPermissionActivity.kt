package com.example.xenaprojecttwo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

// Request SMS permission from the user
class SmsPermissionActivity : AppCompatActivity() {

    private val SMS_PERMISSION_REQUEST = 200

    private lateinit var tvStatus: TextView
    private lateinit var btnRequest: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_permission)

        tvStatus = findViewById(R.id.tvSmsStatus)
        btnRequest = findViewById(R.id.btnRequestSms)

        updateStatusText()

        btnRequest.setOnClickListener {
            requestSmsPermission()
        }
    }

    private fun updateStatusText() {
        val granted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

        tvStatus.text = if (granted) {
            "SMS permission is currently: GRANTED.\nThe app can send goal alerts as text messages."
        } else {
            "SMS permission is currently: DENIED.\nThe app will still work, but no SMS alerts will be sent."
        }
    }

    private fun requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Permission already granted.", Toast.LENGTH_SHORT).show()
            updateStatusText()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_REQUEST
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(
                    this,
                    "SMS permission granted. SMS alerts are now enabled.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "SMS permission denied. App will continue without SMS alerts.",
                    Toast.LENGTH_LONG
                ).show()
            }
            updateStatusText()
        }
    }
}
